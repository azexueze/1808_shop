<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get("show",'order\OrderController@show')->Middleware('test');
Route::post('add','order\OrderController@add');
Route::any('zs','order\OrderController@zs');
Route::any('dele','order\OrderController@dele');
Route::any('upda','order\OrderController@upda');
Route::any('upd','order\OrderController@upd');
Route::any('aja','order\OrderController@aja');
Route::any('updat','order\OrderController@updat');
Route::any('updatete','order\OrderController@updatete');
Route::any('jdjg','order\OrderController@jdjg');


Route::get('index','index\IndexController@index');
Route::get('register','index\IndexController@register');
Route::get('userpage','index\IndexController@userpage')->Middleware('register');
Route::get('login','index\IndexController@login');
Route::post('insertregister','index\IndexController@insertregister');
Route::post('addlogin','index\IndexController@addlogin');
Route::get('shopcart','index\IndexController@shopcart');
Route::any('allshops','index\IndexController@allshops');
Route::any('goodsljz','index\IndexController@goodsljz');
Route::get('newshowed','index\IndexController@newshowed');
Route::any('tel','index\IndexController@tel');
Route::get('demo','index\IndexController@demo');
Route::post('ljz','index\IndexController@ljz');
Route::any('recursion','index\IndexController@recursion');
Route::any('detagoods','index\IndexController@detagoods');
Route::post('jugdecart','index\IndexController@jugdecart');
Route::post('subshopping','index\IndexController@subshopping');
Route::post('subshoppingjian','index\IndexController@subshoppingjian');
Route::post('deleshopping','index\IndexController@deleshopping');
Route::post('ddeleshopping','index\IndexController@ddeleshopping');
Route::post('textshopping','index\IndexController@textshopping');
Route::any('payment','index\IndexController@payment');
Route::any('tbjugdecart','index\IndexController@tbjugdecart');
Route::any('close','index\IndexController@close');
Route::any('address','index\IndexController@address');
Route::any('upaddress','index\IndexController@upaddress');
Route::any('writeaddr','index\IndexController@writeaddr');
Route::any('addwriteaddr','index\IndexController@addwriteaddr');
Route::any('pay','index\IndexController@pay');
Route::any('deleaddress','index\IndexController@deleaddress');
Route::any('updatewriteaddr','index\IndexController@updatewriteaddr');
Route::any('updawriteaddr','index\IndexController@updawriteaddr');
Route::any('buyrecord','index\IndexController@buyrecord');