<?php

namespace App\Http\Controllers\index;

use Illuminate\Http\Request;
use App\models\User;
use App\models\Telconde;
use App\models\Goods;
use App\models\Shopping;
use App\models\Category;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;

class IndexController extends Controller
{
    //首页的静态页面
    public function index(){
        //推荐的商品展示
        $data = Goods::where('is_tell',1)->limit(2)->get(['goods_name','goods_thumb']);
        //猜你喜欢的商品查询
        $lovedata = Goods::where('is_love',1)->get(['goods_id','goods_name','goods_thumb','shop_price']);
        // print_r($data);die;
        return view('index.index',['data'=>$data,'lovedata'=>$lovedata]);
    }

    //流加载方法
    public function ljz(Request $request){
        $page = $request->input('page');
        //定义一页显示几条数据
        $showdata = 2;
        //定义一下每页开始查询的位置
        $seat = ($page-1) * $showdata;
        //猜你喜欢的商品总条数
        $lovecount = Goods::where('is_love',1)->count();
        //计算出一共要有多少页
        $allpage = ceil($lovecount / $showdata);
        // print_r($allpage);
        //开始查询每页的数据
        $seledata = Goods::where('is_love',1)->offset($seat)->limit($showdata)->get();
        // print_r($seledata);
        $data = response(view('index.flow',['lovedata'=>$seledata]))->getcontent();
        $arr = [
            'data'=>$data,
            'page'=>$allpage
        ];
        return $arr;
    }

    //注册页面
    public function register(){
        return view('index.register');
    }

    //我的潮购
    public function userpage(Request $request){
        $uid = $request->session()->get('uid');
        //查询用户的名称
        $userdata = DB::table('user')->where('id',$uid)->get();
        if($userdata){
            $username = $userdata[0]->tel;
        }else{
            $username = '';
        }
        
        return view('index.userpage',['username'=>$username]);
    }

    //登录页面
    public function login(Request $request){
        return view('index.login');
    }

    //登录执行页面
    public function addlogin(Request $request){
        $val = $request->input();
        if(empty($val['tel'])){
            $arr = [
                'figure'=>0,
                'msg'=>'手机号不能为空!'
            ];
            return $arr;
        }

        if(empty($val['pwd'])){
            $arr = [
                'figure'=>0,
                'msg'=>'密码不能为空!',
                
            ];
            return $arr;
        }
        //根据手机号和密码查询数据
        $val['pwd']=md5(md5($val['pwd']));
        $arrdata = User::where('tel',$val['tel'])->where('pwd',$val['pwd'])->first();
        if($arrdata){
            //保存session
            $id = $arrdata['id'];
            $tel = $arrdata['tel'];
            session(['uid'=>$id,'name'=>$tel]);
            if($val['url']==''){
                $arr = [
                    'figure'=>1,
                    'msg'=>'登录成功!'
                ];
                return $arr;
            }else{
                $arr = [
                    'figure'=>2,
                    'msg'=>'登录成功!',
                    'url'=>$val['url'],
                    'id'=>$val['id'],
                ];
                return $arr;
            }
            
        }else{
            $arr = [
                'figure'=>0,
                'msg'=>'用户名或密码不正确请仔细确认!'
            ];
            return $arr;
        };
    }

    //执行注册以及注册验证方法
    public function insertregister(Request $request){
        //接受传过来的值
        $val = $request->input();
        $va['tel'] = $val['tel'];
        //进行密码和确认密码的验证
        if($val['pwd']!=$val['qrpwd']){
            $arr=[
                'figure'=>0,
                'msg'=>'确认密码和密码必须保持一致!'
            ];
            return $arr;
        }
        $va['pwd'] = md5(md5($val['pwd']));
        //进行数据库的查询并验证唯一
        $arrdata = User::where('tel',$val['tel'])->first();
        if(!empty($arrdata)){
            $arr=[
                'figure'=>0,
                'msg'=>'该手机号已被注册过了!'
            ];
            return $arr;
        }else{
            //根据手机号和验证码查询数据
            $seledata = Telconde::where('tel',$val['tel'])->where('code',$val['code'])->where('status',1)->get()->count();
            // print_r($seledata);die;
            if(!$seledata){
                $arr=[
                    'figure'=>0,
                    'msg'=>'验证码错误!'
                ];
                return $arr;
            }else{
                $seledata = Telconde::where('tel',$val['tel'])->where('code',$val['code'])->where('status',1)->get();
                $count = count($seledata);
                for($i=0;$i<$count;$i++){
                    $dqtime = $seledata[$i]['time'];
                    $id = $seledata[$i]['id'];
                };
                $time = time();
                if($time>$dqtime){
                    $arr=[
                        'figure'=>0,
                        'msg'=>'超过了60秒请从新获取验证码!'
                    ];
                    return $arr;
                }
                //进行数据库的修改
            $updata = Telconde::where('id',$id)->update(['status'=>2]);
            }
            
            //进行数据库的添加
            $data = User::insert($va);
            if($data){
                $arr=[
                    'figure'=>1,
                    'msg'=>'注册成功!'
                ];
                return $arr;
            }else{
                $arr=[
                    'figure'=>0,
                    'msg'=>'注册失败!'
                ];
                return $arr;
            }
        };
    }
    

    //所有商品静态页面
    public function allshops(Request $request){
        //查询所有分类的名称
        $namedata = Category::where('parent_id',0)->get(['cate_id','cate_name']);
        //查询所有的商品
        $goodsdata = Goods::orderBy('click_count','desc')->get(['goods_id','goods_name','click_count','goods_number','goods_thumb']);
        $data = view('index.allshops',['namedata'=>$namedata,'goodsdata'=>$goodsdata]);
        // $this->goodsljz();
        return $data;
    }

    public static $arrCate=[];

    //商品详情
    public function detagoods(Request $request){
        $goods_id = $request->input('goods_id');
        $uid = $request->session()->get('uid');
        //根据传过来的id进行数据查询  1.查询图片  2.查询名字
        $img = DB::table('shop_photo')->where('goods_id',$goods_id)->get(['img_url']);
        $goodsdata = Goods::where('goods_id',$goods_id)->get(['goods_id','goods_name','shop_price']);
        //查询购物车所有的商品数量
        $fig = Shopping::where('status',1)->where('uid',$uid)->get(['goods_num'])->toArray();
        $column = array_column($fig,'goods_num');
        $sum = array_sum($column);
        if(count($img)>0){
            return view('index.shopcontent',['img'=>$img,'goodsdata'=>$goodsdata,'sum'=>$sum]);
        }else{
            return view('index.shopcontent',['goodsdata'=>$goodsdata,'sum'=>$sum]);
        }
    }

    //添加购物车判断方法
    public function jugdecart(Request $request){
        //接收传过来的id
        $goods_id = $request->input();
        //根据传过来的id查询goods表的商品库存
        $goods_number = Goods::where('goods_id',$goods_id)->get(['goods_number']);
        // print_r($goods_number[0]->goods_number);die;
        //判断有没有session也就是有没有用户登录
        $uid = $request->session()->get('uid');
        if($uid==''){
            $arr = [
                'figure'=>0,
                'msg'=>'没有用户登录无法加入购物车,是否去登录?'
            ];
            return $arr;
        }else{
            //根据id查询goods表判断是否符合添加购物车的条件
            $goodsdata = Goods::where('goods_id',$goods_id['goods_id'])->where('is_on_sale',1)->get(['goods_id','goods_number']);
            if(count($goodsdata)==0){
                $arr = [
                    'figure'=>1,
                    'msg'=>'该商品不符合添加购物车的条件!'
                ];
                return $arr;
            }else{
                //根据id和uid去数据库进行数据的查询
                $shoppingarr = DB::table('shopping')->where('goods_id',$goods_id['goods_id'])->where('uid',$uid)->where('status',1)->get(['goods_num']);
                if(count($shoppingarr)==0){
                    $arr = [
                        'uid'=>$uid,
                        'goods_id'=>$goods_id['goods_id'],
                        'goods_num'=>1,
                        'status'=>1,
                        'creattime'=>time(),
                    ];
                    // print_r($arr);die;
                    //直接存储数据
                    $inserdata = Shopping::insert($arr);
                    //查询购物车所有的商品数量
                    $fig = Shopping::where('status',1)->where('uid',$uid)->get(['goods_num'])->toArray();
                    $column = array_column($fig,'goods_num');
                    $sum = array_sum($column);
                    if($inserdata){
                        $arr = [
                            'figure'=>2,
                            'fig'=>$sum,
                            'msg'=>'添加购物车成功!'
                        ];
                        return $arr;
                    }
                }else{
                    $goods_num = $shoppingarr[0]->goods_num+1;
                    if($goods_num>$goods_number[0]->goods_number){
                        $arr = [
                            'figure'=>1,
                            'msg'=>'商品库存不足,无法加入购物车!'
                        ];
                        return $arr;
                    }else{
                        //进行修改
                        $updatedata = Shopping::where('goods_id',$goods_id['goods_id'])->where('uid',$uid)->update(['goods_num'=>$goods_num,'creattime'=>time()]);
                        //查询购物车所有的商品数量
                        $fig = Shopping::where('status',1)->where('uid',$uid)->get(['goods_num'])->toArray();
                        $column = array_column($fig,'goods_num');
                        $sum = array_sum($column);
                        if($updatedata){
                            $arr = [
                                'figure'=>2,
                                'fig'=>$sum,
                                'msg'=>'添加购物车成功!'
                            ];
                            return $arr;
                        }
                    }
                }
            }
            
        };
    }


    //添加购物车判断方法
    public function tbjugdecart(Request $request){
        //接收传过来的id
        $goods_id = $request->input();
        //根据传过来的id查询goods表的商品库存
        $goods_number = Goods::where('goods_id',$goods_id)->get(['goods_number']);
        // print_r($goods_number[0]->goods_number);die;
        //判断有没有session也就是有没有用户登录
        $uid = $request->session()->get('uid');
        if($uid==''){
            $arr = [
                'figure'=>0,
                'msg'=>'没有用户登录无法加入购物车,是否去登录?'
            ];
            return $arr;
        }else{
            $arr = [
                'figure'=>1,
                'msg'=>''
            ];
            return $arr;
        };
    }
    //购物车的静态页面
    public function shopcart(Request $request){
        //拿到当前用户的uid
        $uid = $request->session()->get('uid');
        //判断有没有用户登录
        if($uid==''){
            return view('index.login');
        }else{
            //根据当前的uid查询本用户的所有数据
            $userdata = Shopping::join('shop_goods','shop_goods.goods_id','=','shopping.goods_id')->where('shopping.uid',$uid)->where('shopping.dele',1)->where('shopping.status',1)->orderBy('creattime','desc')->get(['shopping.goods_id','goods_name','goods_thumb','shop_price','goods_num']);
            //查询人气推荐
            $is_hot = Goods::where('is_hot',1)->limit(4)->orderBy('goods_id','desc')->get(['goods_id','goods_name','shop_price','click_count','goods_thumb']);
            // print_r($is_hot);
            // print_r($userdata);
            return view('index.shopcart',['shoppingdata'=>$userdata,'is_hot'=>$is_hot]);
            }
    }

    //购物车页面里的小功能+
    public function subshopping(Request $request){
        $val = $request->input();
        // print_r($val);die;
        $count = $val['count']+1;
        //根据传过来的goods_id查询库存
        $goods_number = Goods::where('goods_id',$val['goods_id'])->get(['goods_number']);
        // print_r($goods_num[0]->goods_num);die;
        if($count>$goods_number[0]->goods_number){
            $arr = [
                'figure'=>0,
                'msg'=>'商品数量已超过了库存,没办法加数量了!'
            ];
            return $arr;
        }else{
            //根据传过来的shopping查询数量
            $goods_num = Shopping::where('goods_id',$val['goods_id'])->get(['goods_num']);
            $goods_num = $goods_num[0]->goods_num+1;
            //进行数据库的修改
            $updadata = Shopping::where('goods_id',$val['goods_id'])->update(['goods_num'=>$goods_num]);
            $arr = [
                'figure'=>1,
                'msg'=>$goods_num
            ];
            return $arr;
        };
    }

    //购物车页面里的小功能-
    public function subshoppingjian(Request $request){
        $val = $request->input();
        //根据传过来的shopping查询数量
        $goods_num = Shopping::where('goods_id',$val['goods_id'])->get(['goods_num']);
        $goods_num = $goods_num[0]->goods_num-1;
        if($goods_num<1){
            //进行数据库的修改
            $updadata = Shopping::where('goods_id',$val['goods_id'])->update(['goods_num'=>1]);
            $arr = [
                'figure'=>0,
                'msg'=>1
            ];
            return $arr;
        }else{
            //进行数据库的修改
            $updadata = Shopping::where('goods_id',$val['goods_id'])->update(['goods_num'=>$goods_num]);
            $arr = [
                'figure'=>1,
                'msg'=>$goods_num
            ];
            return $arr;
        }
        
    }

    //购物车单删除
    public function deleshopping(Request $request){
        $uid = $request->session()->get('uid');
        //接收传过来的值
        $goods_id = $request->input();
        //进行修改
        $updatedata = Shopping::where('goods_id',$goods_id['goods_id'])->where('uid',$uid)->update(['dele'=>2]);
        if($updatedata){
            $arr = [
                'figure'=>1,
                'msg'=>'删除成功!'
            ];
            return $arr;
        }
    }

    //购物车多删除
    public function ddeleshopping(Request $request){
        $uid = $request->session()->get('uid');
        //接收传过来的值
        $goods_id = $request->input();
        $count = count($goods_id['goods_id']);
        if($count>1){
            // $goods_id = implode(',',$goods_id['goods_id']);
            //进行修改
            $updatedata = Shopping::whereIn('goods_id',$goods_id['goods_id'])->where('uid',$uid)->update(['dele'=>2]);
        if($updatedata){
            $arr = [
                'figure'=>1,
                'msg'=>'删除成功!'
            ];
            return $arr;
        }
        }else{
            //进行修改
        $updatedata = Shopping::where('goods_id',$goods_id['goods_id'])->where('uid',$uid)->update(['dele'=>2]);
        if($updatedata){
            $arr = [
                'figure'=>1,
                'msg'=>'删除成功!'
            ];
            return $arr;
        }
        }
    }

    //购物车文本框修改
    public function textshopping(Request $request){
        $uid = $request->session()->get('uid');
        //接收传过来的值
        $goods_id = $request->input();
        //根据传过来的goods_id查询库存
        $goods_number = Goods::where('goods_id',$goods_id['goods_id'])->get(['goods_number']);
        // print_r($goods_number[0]->goods_number);die;
        if($goods_id['va']<1){
            //进行修改
            $updatedata = Shopping::where('goods_id',$goods_id['goods_id'])->where('uid',$uid)->update(['goods_num'=>1]);
            // if($updatedata){
                // echo 234;
                $arr = [
                    'figure'=>1,
                    'msg'=>1,
                ];
                return $arr;
            // }
        }else if($goods_id['va']>$goods_number[0]->goods_number){
            //进行修改
            $updatedata = Shopping::where('goods_id',$goods_id['goods_id'])->where('uid',$uid)->update(['goods_num'=>$goods_number[0]->goods_number]);
            $arr = [
                'figure'=>1,
                'msg'=>$goods_number[0]->goods_number,
            ];
            return $arr;
        }else{
            //进行修改
            $updatedata = Shopping::where('goods_id',$goods_id['goods_id'])->where('uid',$uid)->update(['goods_num'=>$goods_id['va']]);
            $arr = [
                'figure'=>1,
                'msg'=>$goods_id['va'],
            ];
            return $arr;
        }
    }

    //所有商品页面左边一小兰
    public function recursion(Request $request){
        //接收传过来的id
        $parent_id = $request->input('id');
        $this->get($parent_id);
        $cate_id = self::$arrCate;
        // $cate_id = implode(',',$cate_id);
        if($cate_id!=0){
            //进行数据的查询
            $goodsdata = Goods::whereIn('cat_id',$cate_id)->get(['goods_id','goods_name','click_count','goods_number','goods_thumb']);
            return view('index.goodscate',['goodsdata'=>$goodsdata]);
        }
    }

    //上面的调用这个方法
    public function get($cate_id){
        //根据传过来的id进行查询数据
        $seledata = Category::where('parent_id',$cate_id)->get(['cate_id']);
        if(count($seledata) > 0){
            foreach($seledata as $val){
                $cate_id = $val->cate_id;
                $this->get($cate_id);
            }
        }
        foreach($seledata as $v){
            $cate_id = $v->cate_id;
            array_push(self::$arrCate,$cate_id);
        }
    }

    //所有商品的流加载
    public function goodsljz(Request $request){
        //接收传过来的页数
        $page = $request->input('page');
        //设置一页显示几条
        $showdata = 6;
        $goodsdata = Goods::count();
        //计算出一共有多少页
        $datacount = ceil($goodsdata/$showdata);
        //计算出每页查询的开始位置
        $placedata = ($page-1)*$showdata;
        //查询所有的商品
        $goodsdata = Goods::orderBy('click_count','desc')->offset($placedata)->limit($showdata)->get(['goods_id','goods_name','click_count','goods_number','goods_thumb']);

        $data = response(view('index.goodsflow',['goodsdata'=>$goodsdata]))->getcontent();
        $arr = [
            'data'=>$data,
            'page'=>$datacount
        ];
        return $arr;
    }

    //最新揭晓静态页面
    public function newshowed(){
        return view('index.newshowed');
    }

    //手机发送验证码
    public function tel(Request $request){
        //接收传过来的手机号
        $tel = $request->input('tel');
        $num = rand(1000,9999);
        $obj = new \send();
        $add = $obj->show($tel,$num);
        if($add==100){
            //定义一个新的存储数据的数组
            $arr=[
                'code'=>$num,
                'tel'=>$tel,
                'time'=>time()+60,
                'status'=>1
            ];
            //进行数据库的存储
            $adddata = Telconde::insert($arr);
            if($adddata){
                $arr=[
                    'figure'=>1,
                    'msg'=>'验证码发送成功!'
                ];
                return $arr;
            }
        }
    }

    //简单的流动效果
    public function demo(){
        return view('index.demo');
    }

    //结算页面
    public function payment(Request $request){
        $uid = $request->session()->get('uid');
        if($uid==''){
            return view('index.login');
        }
        $goods_sn = $request->get('goods_sn');
        //根据goods_sn和uid进行两表联查
        $paymentdata = DB::table('order')->join('shop_order_detail','order.order_sn','=','shop_order_detail.goods_sn')->where('shop_order_detail.user_id',$uid)->where('shop_order_detail.goods_sn',$goods_sn)->get(['shop_order_detail.goods_img','shop_order_detail.buy_number','shop_order_detail.goods_name','shop_order_detail.goods_price','order.order_amount']);
        // print_r($paymentdata);
        //查询该用户有没有填写过收货地址
        $site = DB::table('shop_user_address')->where('user_id',$uid)->get();
        $count = count($site);
        return view('index.payment',['seledata'=>$paymentdata,'count'=>$count]);
    }

    //结算的判断
    public function close(Request $request){
        //接收传过来的值
        $goods_id = $request->input('goods_id');
        // print_r($goods_id);die;
        //拿到uid判断是否有用户登录
        $uid = $request->session()->get('uid');
        // print_r($uid);die;
        if($uid==''){
            $arr = [
                'figure'=>0,
                'msg'=>'shopcart'
            ];
            return $arr;
        }else{
            //根据传过来的id进行数据判断看该订单有没有不符合的商品
            $goodsarr = Goods::whereIn('goods_id',$goods_id)->where('is_on_sale',2)->get(['goods_name']);
            //得到已经下架的商品的名字
            static $goods_namearr = [];
            foreach($goodsarr as $v){
                // $goods_namearr = 
                $goods_namearr[] = $v->goods_name;
            };
            $striarr = implode($goods_namearr,',');
            $goods = count($goodsarr);
            // print_r($striarr);die;
            if($goods>0){
                $arr = [
                    'figure'=>1,
                    'msg'=>'你选中的商品:'."$striarr".' 已下架没有办法生成此订单!'
                ];
                return $arr;
            }
            //根据传过来的id进行数据判断看该订单有没有不符合的商品
            $goodsarr = Goods::join('shopping','shop_goods.goods_id','=','shopping.goods_id')->whereIn('shop_goods.goods_id',$goods_id)->get(['shop_goods.goods_id','shop_goods.goods_name','shop_goods.goods_number','shopping.goods_num','shop_goods.shop_price','shop_goods.goods_thumb']);
            // print_r($goodsarr);die;
            $goods_name = [];
            foreach($goodsarr as $v ){
                if($v['goods_num']>$v['goods_number']){
                    $goods_name[] = $v['goods_name'];
                };
            }
            if(count($goods_name)>0){
                $striarr = implode($goods_name,',');
                $arr = [
                    'figure'=>1,
                    'msg'=>'你选中的商品:'."$striarr".' 超过了商品的总库存,无法生成订单!'
                ];
                return $arr;
            }

            //进行数据库的存储数据
            $time = date('YmdHis',time()).rand(0,9);
            $uid = $request->session()->get('uid');
            $order_amount = [];
            foreach($goodsarr as $v){
                $order_amount[] = intval($v->goods_num)*intval($v->shop_price);
            }
            $order_amount = array_sum($order_amount);
            $arr = [
                'order_sn'=>$time,
                'u_id'=>$uid,
                'order_amount'=>$order_amount,
                'order_pay_type'=>2,
                'pay_status'=>1,
                'pay_way'=>1,
                'status'=>1
            ];
            //进行添加
            $adddata = DB::table('order')->insert($arr);
            $orderdata = DB::table('order')->where('order_sn',$time)->get(['order_id']);
            // print_r($orderdata[0]->order_id);die;
            //进行批量添加
            foreach($goodsarr as $val){
                $arr = [
                    'order_id'=>$orderdata[0]->order_id,
                    'user_id'=>$uid,
                    'goods_sn'=>$time,
                    'goods_id'=>$val->goods_id,
                    'buy_number'=>$val->goods_num,
                    'goods_img'=>$val->goods_thumb,
                    'goods_name'=>"$val->goods_name",
                    'goods_price'=>$val->shop_price,
                    'status'=>1,
                ];
                // print_r($arr);
                $insertdata = DB::table('shop_order_detail')->insert($arr);
            }
            // print_r($insertdata);
            if($insertdata){
                $updatedat = DB::table('shopping')->whereIn('goods_id',$goods_id)->update(['status'=>2]);
                if($updatedat){
                    $arr = [
                        'figure'=>2,
                        'msg'=>'生成订单成功!',
                        'goods_sn'=>$time
                    ];
                    return $arr;
                }
            }
        }
        
    }

    //收货地址静态页面
    public function address(Request $request){
        $uid = $request->session()->get('uid');
        // print_r($uid);die;
        //进行数据的查询
        $paymedata = DB::table('shop_user_address')->where('user_id',$uid)->where('status',1)->get(['address_id','consignee','address','mobile','is_default']);
        // print_r($paymedata);
        return view('index.address',['paymedata'=>$paymedata]);
    }

    //收货地址的删除
    public function deleaddress(Request $request){
        $uid = $request->session()->get('uid');
        $address_id = $request->input('address_id');
        //进行删除
        $deledata = DB::table('shop_user_address')->where('user_id',$uid)->where('address_id',$address_id)->update(['status'=>0]);
        if($deledata){
            $arr = [
                'figure'=>1,
                'msg'=>'删除成功!',
            ];
            return $arr;
        }else{
            $arr = [
                'figure'=>0,
                'msg'=>'删除失败!',
            ];
            return $arr;
        }
    }

    //修改收货地址的状态
    public function upaddress(Request $request){
        $uid = $request->session()->get('uid');
        //接收传过来的值
        $address_id = $request->input('address_id');
        //根据接到的值进行修改已经为1的数据
        $updadata = DB::table('shop_user_address')->where('user_id',$uid)->update(['is_default'=>0]);
        //根据接到的值进行修改
        $updadata = DB::table('shop_user_address')->where('address_id',$address_id)->update(['is_default'=>1]);
        if($updadata){
            $arr = [
                'figure'=>1,
                'msg'=>'设为默认成功'
            ];
            return $arr;
        }else{
            $arr = [
                'figure'=>0,
                'msg'=>'设为默认失败!'
            ];
            return $arr;
        }

    }

    //添加收货地址
    public function writeaddr(Request $request){
        return view('index.writeaddr');
    }

    //添加收货地址
    public function updatewriteaddr(Request $request){
        $uid = $request->session()->get('uid');
        $address_id = $_GET['address_id']?$_GET['address_id']:'';
        //数据的查询
        $seledata = DB::table('shop_user_address')->where('user_id',$uid)->where('address_id',$address_id)->
        get(['consignee','mobile','sign_building','address','is_default']);
        // print_r($seledata);
        return view('index.updatewriteaddr',['seledata'=>$seledata,'address_id'=>$address_id]);
    }

    //执行添加收货地址
    public function addwriteaddr(Request $request){
        $uid = $request->session()->get('uid');
        $data = $request->input();
        // print_r($data);die;
        if(empty($data['xxx'])){
            // echo 23456;die;
            $data = [
                'user_id'=>$uid,
                'consignee' =>$data['consignee'] ,
                'mobile' =>$data['mobile'] ,
                'sign_building' =>$data['sign_building'] ,
                'address' => $data['address'],
                'is_default'=>0,
            ];
            $insertdata = DB::table('shop_user_address')->insert($data);
            if($insertdata){
                $arr = [
                    'figure'=>1,
                    'msg'=>'添加成功!'
                ];
                return $arr;
            }else{
                $arr = [
                    'figure'=>0,
                    'msg'=>'添加失败!'
                ];
                return $arr;
            }
        }else{
            // echo 2345;die;
            //先去进行修改
            $updadata = DB::table('shop_user_address')->where('user_id',$uid)->update(['is_default'=>0]);
            $data = [
                'user_id'=>$uid,
                'consignee' =>$data['consignee'] ,
                'mobile' =>$data['mobile'] ,
                'sign_building' =>$data['sign_building'] ,
                'address' => $data['address'],
                'is_default'=>1,
            ];
            $insertdata = DB::table('shop_user_address')->insert($data);
            if($insertdata){
                $arr = [
                    'figure'=>1,
                    'msg'=>'添加成功!'
                ];
                return $arr;
            }else{
                $arr = [
                    'figure'=>0,
                    'msg'=>'添加失败!'
                ];
                return $arr;
            }
        };
    }


    //执行收货地址修改
    public function updawriteaddr(Request $request){
        $uid = $request->session()->get('uid');
        $data = $request->input();
        // $address_id = $request->input('address_id');
        // print_r($data);die;
        // print_r($data);die;
        if(empty($data['xxx'])){
            // echo 23456;die;
            $date = [
                'user_id'=>$uid,
                'consignee' =>$data['consignee'] ,
                'mobile' =>$data['mobile'] ,
                'sign_building' =>$data['sign_building'] ,
                'address' => $data['address'],
                'is_default'=>0,
            ];
            $insertdata = DB::table('shop_user_address')->where('user_id',$uid)->where('address_id',$data['address_id'])->update($date);
            if($insertdata){
                $arr = [
                    'figure'=>1,
                    'msg'=>'修改成功!'
                ];
                return $arr;
            }else{
                $arr = [
                    'figure'=>0,
                    'msg'=>'修改失败!'
                ];
                return $arr;
            }
        }else{
            // echo 2345;die;
            //先去进行修改
            $updadata = DB::table('shop_user_address')->where('user_id',$uid)->update(['is_default'=>0]);
            $date = [
                'user_id'=>$uid,
                'consignee' =>$data['consignee'] ,
                'mobile' =>$data['mobile'] ,
                'sign_building' =>$data['sign_building'] ,
                'address' => $data['address'],
                'is_default'=>1,
            ];
            $insertdata = DB::table('shop_user_address')->where('user_id',$uid)->where('address_id',$data['address_id'])->update($date);
            if($insertdata){
                $arr = [
                    'figure'=>1,
                    'msg'=>'修改成功!'
                ];
                return $arr;
            }else{
                $arr = [
                    'figure'=>0,
                    'msg'=>'修改失败!'
                ];
                return $arr;
            }
        };
    }


    //执行支付
    public function pay(Request $request){
        $uid = $request->session()->get('uid');
        $goods_sn = $request->input('goods_sn');
        $dsf = $request->input('paymen');
        // print_r($dsf);die;
        if($dsf==3){
            $jjg = 1;
            //进行数据库的查询
            $data = DB::table('shop_user_address')->where('user_id',$uid)->where('is_default',1)->get(['consignee','address','mobile']);
            $data2 = DB::table('order')->where('order_sn',$goods_sn)->where('u_id',$uid)->where('status',1)->get(['order_amount']);
            // print_r($data2);die;
            // print_r($data);
            $arr = [
                'order_sn'=>$goods_sn,
                'user_id'=>$uid,
                'consignee'=>$data[0]->consignee,
                'address'=>$data[0]->address,
                'mobile'=>$data[0]->mobile,
                'goods_amount'=>$data2[0]->order_amount,
                'order_amount'=>intval($data2[0]->order_amount)+intval($jjg),
                'add_time'=>time(),
            ];
            //进行数据库的添加
            $insertdata = DB::table('shop_order_info')->insert($arr);
            if($insertdata){
                $arr = [
                    'figure'=>1,
                    'msg'=>'添加失败!',
                    'mone'=>intval($data2[0]->order_amount)+intval($jjg),
                ];
                return $arr;
            }else{
                $arr = [
                    'figure'=>0,
                    'msg'=>'添加失败!'
                ];
                return $arr;
            }
        }else{
            //进行数据库的查询
            $data = DB::table('shop_user_address')->where('user_id',$uid)->where('is_default',1)->get(['consignee','address','mobile']);
            $data2 = DB::table('order')->where('order_sn',$goods_sn)->where('u_id',$uid)->where('status',1)->get(['order_amount']);
            // print_r($data2);die;
            // print_r($data);
            $arr = [
                'order_sn'=>$goods_sn,
                'user_id'=>$uid,
                'consignee'=>$data[0]->consignee,
                'address'=>$data[0]->address,
                'mobile'=>$data[0]->mobile,
                'goods_amount'=>$data2[0]->order_amount,
                'order_amount'=>$data2[0]->order_amount,
                'add_time'=>time(),
            ];
            //进行数据库的添加
            $insertdata = DB::table('shop_order_info')->insert($arr);
            if($insertdata){
                $arr = [
                    'figure'=>1,
                    'msg'=>'添加失败!',
                    'mone'=>$data2[0]->order_amount,
                ];
                return $arr;
            }else{
                $arr = [
                    'figure'=>0,
                    'msg'=>'添加失败!'
                ];
                return $arr;
            }
        }
    }

    //潮购记录
    public function buyrecord(Request $request){
        $uid = $request->session()->get('uid');
        //查询人气推荐
        $is_hot = Goods::where('is_hot',1)->limit(4)->orderBy('goods_id','desc')
        ->get(['goods_id','goods_name','shop_price','click_count','goods_thumb']);
        //查询数据
        $seledata = DB::table('shop_order_detail')->where('shop_order_detail.user_id',$uid)->join('shop_goods','shop_order_detail.goods_id','=','shop_goods.goods_id')->get(['shop_goods.goods_name','shop_goods.goods_name','shop_goods.goods_id','shop_goods.goods_thumb']);
        // print_r($seledata);
        return view('index.buyrecord',['is_hot'=>$is_hot,'seledata'=>$seledata]);
    }
}