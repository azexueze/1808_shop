<?php

namespace App\Http\Controllers\order;

use Illuminate\Support\Facades\DB;
use App\models\Add;
use App\models\Classify;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class OrderController extends Controller
{
    public function show(){
        $users = Classify::all();
        return view('order\order',['add'=>$users]);
    }
    public function add(Request $request){
        $data = $request->input();
        //进行数据的添加
        $date = Add::insert($data);
        if($date==1){
            return 1;
        }
    }
    public function zs(Request $request){
        //进行数据的查询
        // $date = DB::table('add')->paginate(1);
        $date = Add::paginate(3);
        return view('order\show',['add'=>$date]);
    }

    public function aja(Request $request){
        //接受传过来的值
        $sell  = $request->input('sell');
        $putaway  = $request->input('putaway');
        if($sell=='' && $putaway==''){
            return 2;
        }
        if($sell!='' && $putaway!=''){
            $arrdata = Add::where('is_sell',$sell)->where('is_putaway',$putaway)->paginate(3);
            return view('order\show',['add'=>$arrdata]);
        }
        if($sell!=''){
            $arrdata = Add::where('is_sell',$sell)->paginate(3);
            return view('order\show',['add'=>$arrdata]);
        }
        if($putaway!=''){
            $arrdata = Add::where('is_putaway',$putaway)->paginate(3);
            return view('order\show',['add'=>$arrdata]);
        }

        
        // print_r($putaway);
        // $arrdata = Add::where('is_sell',$sell)->where('is_putaway',$putaway)->get();
        // print_r($arrdata);
    }
    public function dele(Request $request){
        //接受传过来的id
        $id = $request->input('id');
        //进行数据的删除
        // $data = DB::table('add')->where('id',$id)->delete();
        $data =  Add::find($id);
        $data->delete();
        if($data){
            return 1;
        };
        // $obj =  Add::find($id);
        // $obj->delete();
    }
    public function upda(Request $request){
        $is_sell = $request->input();
        // print_r($is_sell['id']);die;
        //进行数据库的修改
        $data = Add::find($is_sell['id']);
        $data->is_sell = $is_sell['is_sell'];
        $data->save();
        // $data = DB::table('add')->where('id',$is_sell['id'])->update(['is_sell'=>$is_sell['is_sell']]);
        exit;
        if($data){
            return 1;
        };
    }

    public function updat(Request $request){
        //接收传过来的id
        $id = $request->input('id');
        //根据id进行数据的查询
        $arrdata = Add::where('id',$id)->get()->toarray();
        $seledata = Classify::get();
        // print_r($seledata);die;
        return view('order.updat',['arrdata'=>$arrdata,'seledata'=>$seledata]);
    }

    public function updatete(Request $request){
        $val = $request->input();
        //进行数据库的修改
        $updatedata = Add::find($val['id']);
        $updatedata->name = $val['name'];
        $updatedata->classify = $val['classify'];
        $updatedata->descri = $val['descri'];
        $updatedata->is_sell = $val['is_sell'];
        $updatedata->is_putaway = $val['is_putaway'];
        $updatedata->save();
        if($updatedata){
            return 1;
        };
    }

    public function upd(Request $request){
        $is_sell = $request->input();
        //进行数据库的修改
        // $data = DB::table('add')->where('id',$is_sell['id'])->update(['is_putaway'=>$is_sell['is_sell']]);
        $data = Add::find($is_sell['id']);
        $data->is_putaway = $is_sell['is_sell'];
        $data->save();
        if($data){
            return 1;
        };
    }

    public function jdjg(Request $request){
        $data = $request->input();
        //进行修改的操作
        $upddata = Add::find($data['id']);
        $upddata->name = $data['name'];
        $upddata->save();
        if($upddata){
            return 1;
        }
    }
}
