<?php

namespace App\Http\Controllers\app\http\controller\index;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class IndexController extends Controller
{
    //
}
