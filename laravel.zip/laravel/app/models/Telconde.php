<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Telconde extends Model
{
    protected $table="telconde";
    public $timestamps = false;
}
