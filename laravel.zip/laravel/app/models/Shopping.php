<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Shopping extends Model
{
    protected $table = 'shopping';
    public $timestamps = false;
}
