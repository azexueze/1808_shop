<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Add extends Model
{
    protected $table = 'add';
    public $timestamps = false;
}
