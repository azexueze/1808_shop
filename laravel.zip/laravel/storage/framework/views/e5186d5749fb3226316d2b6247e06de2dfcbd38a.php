<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<script src="\js\jquery-3.1.1.min.js"></script>
<body>
    <form action="/add" method="post" id="for">
    <table border="1">
        <tr>
            <td>名称:</td>
            <td>
                <input type="text" name="name">
            </td>
        </tr>
        <tr>
            <td>分类:</td>
            <td>
                <select name="classify">
                    <?php foreach($add as $k=>$v){?>
                    <option value="<?php echo e($v->id); ?>"><?php echo e($v->name); ?></option>
                    <?php }?>
                </select>
            </td>
        </tr>
        <tr>
            <td>描述:</td>
            <td>
                <textarea name="descri" id="" cols="30" rows="10"></textarea>
            </td>
        </tr>
        <tr>
            <td>是否热销:</td>
            <td>
                <input type="radio" name="is_sell" value="1">是
                <input type="radio" name="is_sell" value="0">否
            </td>
        </tr>
        <tr>
            <td>是否上架:</td>
            <td>
                <input type="radio" name="is_putaway" value="1">是
                <input type="radio" name="is_putaway" value="0">否
            </td>
        </tr>
        <tr>
            <td></td>
            <td>
                <input type="button" class="qr" value="确认">
            </td>
        </tr>
    </table>
    
    </form>
</body>
</html>

<script>
    $('.qr').click(function(){
        var data =$('#for').serialize();
        $.ajax({
            type:'POST',
            url:'add',
            data:data,
        }).done(function(msg){
            if(msg==1){
                window.location.href="zs";
            };
        });
    })
</script>
