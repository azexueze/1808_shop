<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<style>
	.pagination li{float:left;margin-left: 20px;list-style: none;}
</style>
<script src="\js\jquery-3.1.1.min.js"></script>
<div id="emp">
<body>
    <form action="">
        <table border="1">
            <tr>
                <select name="sell" id="">
                    <option value="">请选择是否热销</option>
                    <option value="1">是</option>
                    <option value="0">否</option>
                </select>
                <select name="putaway" id="">
                    <option value="">请选择是否上架</option>
                    <option value="1">是</option>
                    <option value="0">否</option>
                </select>
                <td>
                    <input id="ss" type="button" value="搜索">
                </td>
            </tr>
        </table>
    </form>
    <table border="1" >
        <tr>
            <td>用户id</td>
            <td>名称</td>
            <td>分类</td>
            <td>描述</td>
            <td>是否热销</td>
            <td>是否上架</td>
            <td>操作</td>
        </tr>
        <?php $__currentLoopData = $add; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($v->id); ?></td>
            <td><?php echo e($v->name); ?></td>
            <td><?php echo e($v->classify); ?></td>
            <td><?php echo e($v->descri); ?></td>
            <td id="<?php echo e($v->id); ?>"><?php if($v->is_sell==1){
                    echo "<input type='button' id='is_sell' value='是'>";
                }else{
                    echo "<input type='button' id='is_sell' value='否'>";
                    }; ?></td>
            <td id="<?php echo e($v->id); ?>"><?php if($v->is_putaway==1){echo "<input type='button' id='is_putaway' value='是'>";}else{
                echo "<input type='button' id='is_putaway' value='否'>";
            } ?></td>
            <td>
                <a href="updat?id=<?php echo e($v->id); ?>">[ 修改 </a>
                <a href="javascript:;" onclick="dele(<?php echo e($v->id); ?>)">删除 ]</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <?php echo e($add->links()); ?>

</body>
</div>
</html>
<script>
    $(document).on('click','#is_sell',function(){
        var na = $(this).val();
        var id = $(this).parent().attr('id');
        if(na=='是'){
            $(this).val('否');
            nam=0
        }else{
            $(this).val('是');
            nam=1;
        }
        var ii = $(this);
        //进行ajax的传输
        $.ajax({
            type:'POST',
            url:'upda',
            data:{'is_sell':nam,'id':id},
        }).done(function(msg){
            
        })
    });


    $(document).on('click','#is_putaway',function(){
        var na = $(this).val();
        var id = $(this).parent().attr('id');
        if(na=='是'){
            $(this).val('否');
            nam=0
        }else{
            $(this).val('是');
            nam=1;
        }
        //进行ajax的传输
        $.ajax({
            type:'POST',
            url:'upd',
            data:{'is_sell':nam,'id':id},
        }).done(function(msg){
        })
    });
    function dele($id){
        $.ajax({
            type:"POST",
            url:'dele',
            data:{'id':$id}
        }).done(function(msg){
            if(msg==1){
                alert('删除成功!');
                window.location.href="zs";
            };
        })
    }

    $('#ss').click(function(){
        var sell = $("select[name='sell']").val();
        var putaway = $("select[name='putaway']").val();
        $.ajax({
            type:'post',
            url:'aja',
            data:{'sell':sell,'putaway':putaway},
            success:function(msg){
                if(msg==2){
                    alert('请选择搜索条件!');
                }else{
                    $('#emp').html(msg);
                };
            }
        })
    })
        
</script>