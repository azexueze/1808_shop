<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>购物车</title>
    <meta content="app-id=518966501" name="apple-itunes-app" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, user-scalable=no, maximum-scale=1.0" />
    <meta content="yes" name="apple-mobile-web-app-capable" />
    <meta content="black" name="apple-mobile-web-app-status-bar-style" />
    <meta content="telephone=no" name="format-detection" />
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="0" />
    <link href="css/comm.css" rel="stylesheet" type="text/css" />
    <link href="css/cartlist.css" rel="stylesheet" type="text/css" />
</head>
<body id="loadingPicBlock" class="g-acc-bg">
    <input name="hidUserID" type="hidden" id="hidUserID" value="-1" />
    <div>
        <!--首页头部-->
        <div class="m-block-header">
            <a href="/" class="m-public-icon m-1yyg-icon"></a>
            <a href="/" class="m-index-icon">编辑</a>
        </div>
        <!--首页头部 end-->
        <div class="g-Cart-list">
            <ul id="cartBody">
                @foreach($shoppingdata as $v)
                    <li value="{{$v->goods_id}}">
                        <s class="xuan current"></s>
                        <a class="fl u-Cart-img" href="/v44/product/12501977.do">
                            <img src="/uploads/{{$v->goods_thumb}}" border="0" alt="暂无图片">
                        </a>
                        <div class="u-Cart-r">
                            <a href="/v44/product/12501977.do" class="gray6">{{$v->goods_name}}</a>
                            <span class="gray9">
                                <em>剩余124人次</em>
                            </span>
                            <div class="num-opt">
                                <em class="num-mius dis min" value="{{$v->goods_id}}"><i></i></em>
                                <input class="text_box" name="num" maxlength="6" type="text"  id="{{$v->shop_price}}" value="{{$v->goods_num}}" codeid="12501977">
                                <em class="num-add add" value="{{$v->goods_id}}"><i></i></em>
                            </div>
                            <a href="javascript:;" name="delLink" cid="12501977" isover="0" class="z-del"><s></s></a>
                        </div>    
                    </li>
                @endforeach
            </ul>
            <div id="divNone" class="empty "  style="display: none"><s></s><p>您的购物车还是空的哦~</p><a href="https://m.1yyg.com" class="orangeBtn">立即潮购</a></div>
        </div>
        <div id="mycartpay" class="g-Total-bt g-car-new" style="">
            <dl>
                <dt class="gray6">
                    <s class="quanxuan current"></s>全选
                    <p class="money-total">合计<em class="orange total"><span>￥</span>17.00</em></p>
                    
                </dt>
                <dd>
                    <a href="javascript:;" id="a_paymen" class="orangeBtn w_account remove">删除</a>
                    <a href="javascript:;" id="a_payment" class="orangeBtn w_account">去结算</a>
                </dd>
            </dl>
        </div>
        <div class="hot-recom">
            <div class="title thin-bor-top gray6">
                <span><b class="z-set"></b>人气推荐</span>
                <em></em>
            </div>
            <div class="goods-wrap thin-bor-top">
                <ul class="goods-list clearfix">
                    @foreach($is_hot as $val)
                        <li>
                            <a href="detagoods?goods_id={{$val->goods_id}}" class="g-pic">
                                <img src="/uploads/{{$val->goods_thumb}}" alt="暂无图片" width="136" height="136">
                            </a>
                            <p class="g-name">
                                <a href="https://m.1yyg.com/v44/products/23458.do">{{$val->goods_name}}</a>
                            </p>
                            <ins class="gray9">价值:￥{{$val->shop_price}}</ins>
                            <div class="btn-wrap">
                                <div class="Progress-bar">
                                    <p class="u-progress">
                                        <span class="pgbar" style="width:1%;">
                                            <span class="pging"></span>
                                        </span>
                                    </p>
                                </div>
                                <div class="gRate" data-productid="23458">
                                    <a href="javascript:;"><s></s></a>
                                </div>
                            </div>
                        </li>
                    @endforeach
                </ul>
            </div>
        </div>

       
        

<div class="footer clearfix">
    <ul>
        <li class="f_home"><a href="index" ><i></i>潮购</a></li>
        <li class="f_announced"><a href="newshowed" ><i></i>最新揭晓</a></li>
        <li class="f_single"><a href="/v41/post/index.do" ><i></i>晒单</a></li>
        <li class="f_car"><a id="btnCart" href="shopcart" class="hover"><i></i>购物车</a></li>
        <li class="f_personal"><a href="userpage" ><i></i>我的潮购</a></li>
    </ul>
</div>

<script src="js/jquery-1.11.2.min.js"></script>
<script src="\layui\css\layui.css"></script>
<script src="\layui\layui.js"></script>
<!---商品加减算总数---->
    <script type="text/javascript">
        layui.use('layer',function(){
            $(function () {
            $(".add").click(function () {
                var t = $(this).prev();
                var goods_id = $(this).attr('value');
                //进行ajax传输
                $.ajax({
                    type:'post',
                    url:'subshopping',
                    data:{goods_id:goods_id,count:t.val()},
                    success:function(msg){
                        if(msg.figure==0){
                            layer.msg(msg.msg);
                        }else if(msg.figure==1){
                            t.val(parseInt(t.val()) + 1);
                            GetCount();
                        }
                    }
                })
            })
            $(".min").click(function () {
                    var t = $(this).next();
                    if(t.val()==0){
                        var count  = 0;
                    }else{
                        var count = t.val();
                    }
                    
                    if(count>1){
                        var goods_id = $(this).attr('value');
                        //进行ajax传输
                        $.ajax({
                            type:'post',
                            url:'subshoppingjian',
                            data:{goods_id:goods_id,count:count},
                            success:function(msg){
                                if(msg.figure==1){
                                    t.val(parseInt(t.val()) - 1);
                                    GetCount();
                                }
                            }
                        })
                    }
                })
            })

            //单删
            $('.z-del s').click(function(){
                var goods_id  = $(this).parent().prev().find('.min').attr('value');
                //进行ajax传输
                $.ajax({
                    type:'post',
                    url:'deleshopping',
                    data:{goods_id:goods_id},
                    success:function(msg){
                        if(msg.figure==1){
                            layer.msg(msg.msg);
                            history.go(0);
                        }
                    }
                })
            })

            //批量删除
            $('#a_paymen').click(function(){
                // alert('dfdfdfkdjkfjejek');
                var goods_id = [];
                $('.xuan.current').each(function(){
                    goods_id.push($(this).parent().attr('value'));
                })
                // var goods_id = json_encode(goods_id);
                // alert(goods_id);
                //进行ajax传输
                $.ajax({
                    type:'post',
                    url:'ddeleshopping',
                    data:{goods_id:goods_id},
                    success:function(msg){
                        if(msg.figure==1){
                            layer.msg(msg.msg);
                            history.go(0);
                            return false;
                        }
                    }
                })
                
            });

            //文本框
            $('.text_box').blur(function(){
                alert('嗯嗯');
                var th = $(this);
                var va = parseInt($(this).val());
                var goods_id = $(this).prev().attr('value');
                //进行ajax传输
                $.ajax({
                    type:'post',
                    url:'textshopping',
                    data:{va:va,goods_id:goods_id},
                    success:function(msg){
                        if(msg.figure==1){
                            th.val(msg.msg);
                        }
                    }
                })
            });

            //去结算
            $('#a_payment').click(function(){
                // alert(123456789);
                var goods_id = [];
                // var goods_num = [];
                $('.xuan.current').each(function(){
                    goods_id.push($(this).parent().attr('value'));
                    // goods_num.push($(this).parent().find('.text_box').attr('value'));
                })
                if(goods_id==''){
                    layer.msg('请选择商品!');
                    return false;
                }
                //进行ajax的传输
                $.ajax({
                    type:'post',
                    url:'close',
                    data:{goods_id:goods_id},
                    success:function(msg){
                        if(msg.figure==0){
                            window.location.href="login?url="+msg.msg;
                        }else if(msg.figure==1){
                            layer.msg(msg.msg);
                        }else if(msg.figure==2){
                            layer.msg(msg.msg);
                            window.location.href="payment?goods_sn="+msg.goods_sn;
                        }
                    }
                })
                /**不要删除还有用
                    var jg = $('.orange.total').text();
                    window.location.href="payment?goods_id="+goods_id+"&jg="+jg;
                 */
            })
        })
        

        
    </script>



    
    <script>

    // 全选        
    $(".quanxuan").click(function () {
        if($(this).hasClass('current')){
            $(this).removeClass('current');

             $(".g-Cart-list .xuan").each(function () {
                if ($(this).hasClass("current")) {
                    $(this).removeClass("current"); 
                } else {
                    $(this).addClass("current");
                } 
            });
            GetCount();
        }else{
            $(this).addClass('current');

             $(".g-Cart-list .xuan").each(function () {
                $(this).addClass("current");
                
            });
            GetCount();
        }

        // var shop_price = $('.xuan current').attr('value');
        // alert(shop_price);
    });
    // 单选
    $(".g-Cart-list .xuan").click(function () {
        if($(this).hasClass('current')){

            $(this).removeClass('current');

        }else{
            $(this).addClass('current');
        }
        if($('.g-Cart-list .xuan.current').length==$('#cartBody li').length){
                $('.quanxuan').addClass('current');

            }else{
                $('.quanxuan').removeClass('current');
            }
        // $("#total2").html() = GetCount($(this));
        GetCount();
        //alert(conts);
    });
  // 已选中的总额
    function GetCount() {
        var conts = 0;
        var aa = 0; 
        $(".g-Cart-list .xuan").each(function () {
            if ($(this).hasClass("current")) {
                for (var i = 0; i < $(this).length; i++) {
                    jiage = parseInt($(this).parents('li').find('input.text_box').attr('id'));
                    conts += parseInt($(this).parents('li').find('input.text_box').val())*jiage;
                }
            }
        });
        
         $(".total").html('<span>￥</span>'+(conts).toFixed(2));
         return false;
    }
    GetCount();
</script>
</body>
</html>
