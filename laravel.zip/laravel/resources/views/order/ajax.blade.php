<tr>
            <td>用户id</td>
            <td>名称</td>
            <td>分类</td>
            <td>描述</td>
            <td>是否热销</td>
            <td>是否上架</td>
            <td>操作</td>
        </tr>
        @foreach($add as $k=>$v)
        <tr>
            <td>{{$v->id}}</td>
            <td>{{$v->name}}</td>
            <td>{{$v->classify}}</td>
            <td>{{$v->descri}}</td>
            <td id="{{$v->id}}"><?php if($v->is_sell==1){
                    echo "<input type='button' id='is_sell' value='是'>";
                }else{
                    echo "<input type='button' id='is_sell' value='否'>";
                    }; ?></td>
            <td id="{{$v->id}}"><?php if($v->is_putaway==1){echo "<input type='button' id='is_putaway' value='是'>";}else{
                echo "<input type='button' id='is_putaway' value='否'>";
            } ?></td>
            <td>
                <a href="updat?id={{$v->id}}">[ 修改 </a>
                <a href="javascript:;" onclick="dele({{$v->id}})">删除 ]</a>
            </td>
        </tr>
        @endforeach