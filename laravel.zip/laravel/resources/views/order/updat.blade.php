<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<script src="\js\jquery-3.1.1.min.js"></script>
<body>
    <form action="/add" method="post" id="for">
    <tr>
        <td>
            <input type="hidden" name="id" value="{{$arrdata[0]['id']}}">
        </td>
    </tr>
    <table border="1">
    
        <tr>
            <td>名称:</td>
            <td>
                <input type="text" name="name" value="{{$arrdata[0]['name']}}">
            </td>
        </tr>
        <tr>
            <td>分类:</td>
            <td>
                <select name="classify">
                    @foreach($seledata as $v)
                    <option value="{{$v->id}}" <?php if($v->id==$arrdata[0]['classify']){echo 'selected';}?>>{{$v->name}}</option>
                    @endforeach
                </select>
            </td>
        </tr>
        <tr>
            <td>描述:</td>
            <td>
                <textarea name="descri" id="" cols="30" rows="10">{{$arrdata[0]['descri']}}</textarea>
            </td>
        </tr>
        <tr>
            <td>是否热销:</td>
            <td>
                <input type="radio" name="is_sell" value="1" <?php if($arrdata[0]['is_sell']==1){echo 'checked';}?>>是
                <input type="radio" name="is_sell" value="0"  <?php if($arrdata[0]['is_sell']==0){echo 'checked';}?>>否
            </td>
        </tr>
        <tr>
            <td>是否上架:</td>
            <td>
                <input type="radio" name="is_putaway" value="1"  <?php if($arrdata[0]['is_putaway']==1){echo 'checked';}?>>是
                <input type="radio" name="is_putaway" value="0" <?php if($arrdata[0]['is_putaway']==0){echo 'checked';}?>>否
            </td>
        </tr>
        <tr>
            <td></td>
            <td>
                <input type="button" class="qr" value="确认">
            </td>
        </tr>
    </table>
    
    </form>
</body>
</html>

<script>
    $('.qr').click(function(){
        var data =$('#for').serialize();
        var url = "updatete";
        $.ajax({
            type:'POST',
            url:url,
            data:data,
        }).done(function(msg){

            if(msg==1){
                alert('修改成功');
                window.location.href="zs";
            };
        });
    })
</script>
